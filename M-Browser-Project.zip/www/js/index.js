document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    document.getElementById('login-btn').addEventListener('click', function() {
        
        // Yahan apni details likhein
        const userID = "APNI_ID_YAHAN_LIKHEIN";
        const password = "APNA_PASSWORD_YAHAN_LIKHEIN";
        
        // AIOU LMS3 ka login URL
        const loginUrl = 'https://www.google.com';
        
        var ref = cordova.InAppBrowser.open(loginUrl, '_blank', 'location=yes,toolbar=yes');
        
        ref.addEventListener('loadstop', function() {
            // JavaScript Injection for Auto-Fill
            const jsCode = `
                var u = document.getElementById('username');
                var p = document.getElementById('password');
                var b = document.getElementById('loginbtn');
                
                if (u && p && b) {
                    u.value = '${userID}';
                    p.value = '${password}';
                    b.click();
                }
            `;
            ref.executeScript({ code: jsCode });
        });
    });
}
